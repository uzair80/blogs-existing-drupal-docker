<?php

namespace Drupal\blazy_test;

use Drupal\blazy\BlazyFormatter;

/**
 * Implements GridStackFormatterInterface.
 *
 * @todo remove no longer needed, most dups were merged into BlazyManager.
 */
class BlazyFormatterTest extends BlazyFormatter implements BlazyFormatterTestInterface {}


***
## <a name="aspect-ratio-template"></a>ASPECT RATIO TEMPLATE
### Tools to check aspect ratio:
http://size43.com/jqueryVideoTool.html

### Common resolutions:
http://en.wikipedia.org/wiki/List_of_common_resolutions

### Aspect ratio 4:3
* 640x480
* 800x600
* 1024x768
* 1152x864
* 1280x960
* 1400x1050
* 1600x1200
* 2048x1536
* 3200x2400
* 4000x3000
* 6400x4800

### Aspect ratio 16:9
* 640x360
* 853x480
* 960x540
* 1024x576
* 1280x720
* 1366x768
* 1600x900
* 1920x1080
* 2048x1152
* 2560x1440
* 2880x1620
* 3840x2160
* 4096x2304
* 7680x4320

### Aspect ratio 16:10
* 1440x900
* 1680x1050
* 1920x1200
* 2560x1600
* 3840x2400
* 7680x4800

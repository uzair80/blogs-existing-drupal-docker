<?php

namespace Drupal\blazy;

/**
 * Provides common field formatter-related methods: Blazy, Slick, etc.
 *
 * @todo deprecate for BlazyFormatter at blazy:8.2.1, and remove at 3.x.
 */
class BlazyFormatterManager extends BlazyFormatter {}

<?php

namespace Drupal\blazy\Dejavu;

use Drupal\blazy\Config\Entity\BlazyConfigEntityBase as ConfigEntityBase;

/**
 * Defines the common configuration entity.
 *
 * @todo deprecated in blazy:8.x-2.9 and is removed from blazy:8.x-3.0. Use
 *   Drupal\blazy\Config\Entity\BlazyConfigEntityBase instead.
 */
abstract class BlazyConfigEntityBase extends ConfigEntityBase {}

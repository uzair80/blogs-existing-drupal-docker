<?php

namespace Drupal\blazy;

use Drupal\blazy\Media\BlazyMedia as Media;

/**
 * Provides extra utilities to work with core Media.
 *
 * @todo deprecated at 2.6, and removed at 3.x. Use
 * Drupal\blazy\Media\BlazyMedia instead.
 */
class BlazyMedia extends Media {}
